# rpg - Banco dedos que armazena equipamentos

