<?php
//Aplicar futuramente como atributo de ferramenta e tabela no banco de dados.

class Habilidade{
    private string $nome;
    private string $efeito;

    public function getNome(): string
    {
        return $this->nome;
    }

    public function setNome(string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    public function getEfeito(): string
    {
        return $this->efeito;
    }

    public function setEfeito(string $efeito): self
    {
        $this->efeito = $efeito;

        return $this;
    }
}
