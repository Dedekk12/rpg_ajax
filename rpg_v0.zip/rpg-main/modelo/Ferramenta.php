<?php
class Ferramenta
{
    protected int $id;
    protected string $nome;
    protected string $grupo;
    protected string $descricao;
    protected float $preco;
    protected string $material;
    protected string $requisito;
    protected string $imagem;

    public function __construct(string $nome, string $grupo,string $descricao, float $preco, string $material, string $requisito, string $imagem)
    {
        $this->nome = $nome;
        $this->grupo = $grupo;
        $this->descricao = $descricao;
        $this->preco = $preco;
        $this->material = $material;
        $this->requisito = $requisito;
        $this->imagem = $imagem;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): self
    {
        $this->id = $id;

        return $this;
    }

    public function getNome(): string
    {
        return $this->nome;
    }

    public function setNome(string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    public function getGrupo(): string
    {
        return $this->grupo;
    }

    public function setGrupo(string $grupo): self
    {
        $this->grupo = $grupo;

        return $this;
    }

    public function getDescricao(): string
    {
        return $this->descricao;
    }

    public function setDescricao(string $descricao): self
    {
        $this->descricao = $descricao;

        return $this;
    }

    public function getPreco(): float
    {
        return $this->preco;
    }

    public function setPreco(float $preco): self
    {
        $this->preco = $preco;

        return $this;
    }

    public function getMaterial(): string
    {
        return $this->material;
    }

    public function setMaterial(string $material): self
    {
        $this->material = $material;

        return $this;
    }


    public function getTipo(): string
    {
        return "F";
    }


    public function getRequisito(): string
    {
        return $this->requisito;
    }

    public function setRequisito(string $requisito): self
    {
        $this->requisito = $requisito;

        return $this;
    }

    public function getImagem(): string
    {
        return $this->imagem;
    }

    public function setImagem(string $imagem): self
    {
        $this->imagem = $imagem;

        return $this;
    }
}
