<?php

require_once("Ferramenta.php");

class Arma extends Ferramenta{
    private int $dano;
    private int $bonus;
    private string $tipoDano;

    public function __construct
    (string $nome,string $grupo,string $descricao, float $preco , string $material, string $requisito, string $imagem, int $dano, int $bonus, string $tipoDano)
    {
        //$this->id= $id;
        $this->nome = $nome;
       $this->grupo = $grupo;
        $this->descricao = $descricao;
        $this->preco = $preco;
        $this->material = $material;
        $this->requisito = $requisito;
        $this->imagem = $imagem;
        $this->dano = $dano;
        $this->bonus = $bonus;
        $this->tipoDano = $tipoDano;
    }

    public function getDano(): int
    {
        return $this->dano;
    }

    public function setDano(int $dano): self
    {
        $this->dano = $dano;

        return $this;
    }

    public function getBonus(): int
    {
        return $this->bonus;
    }

    public function setBonus(int $bonus): self
    {
        $this->bonus = $bonus;

        return $this;
    }

    public function getTipoDano(): string
    {
        return $this->tipoDano;
    }

    public function setTipoDano(string $tipoDano): self
    {
        $this->tipoDano = $tipoDano;

        return $this;
    }

    public function getTipo(): string
    {
        return "A";
    }
}
