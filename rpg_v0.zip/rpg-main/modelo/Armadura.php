<?php

require_once("Ferramenta.php");

class Armadura extends Ferramenta{
    private int $defesa;
    private string $conjunto;

    public function __construct(string $nome,string $grupo,string $descricao, float $preco , string $material, string $requisito, string $imagem, int $defesa, string $conjunto)
    {
        //$this->id= $id;
        $this->nome = $nome;
        $this->grupo = $grupo;
        $this->descricao = $descricao;
        $this->preco = $preco;
        $this->material = $material;
        $this->requisito = $requisito;
        $this->imagem = $imagem;
        $this->defesa = $defesa;
        $this->conjunto = $conjunto;
    }


    public function getDefesa(): int
    {
        return $this->defesa;
    }

    public function setDefesa(int $defesa): self
    {
        $this->defesa = $defesa;

        return $this;
    }

    public function getConjunto(): string
    {
        return $this->conjunto;
    }

    public function setConjunto(string $conjunto): self
    {
        $this->conjunto = $conjunto;

        return $this;
    }


    public function getTipo(): string
    {
        return "D";
    }
}
