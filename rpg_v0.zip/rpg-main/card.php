<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
//Requisitos
require_once "util/Conexao.php";
require_once "dao/FerramentasDAO.php";

//Programa
$ferramentas = FerramentaDAO::buscarFerramenta($_GET["id"]);
$ferramenta = $ferramentas[0];


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card </title>
    <link rel="stylesheet" href="style/bootstrap.min.css">
    <link rel="stylesheet" href="style/style.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400..700&display=swap" rel="stylesheet">

    <style>
        .card {
            animation: 3s ease-in change;
        }
    </style>

</head>

<body>

    <audio id="tema" src="audio/the-bard's-song.mp3" loop ></audio>

    <div class="container mt-4 mb-4">
        <div class="card d-flex flex-column text-center align-self-center rounded-4 bg-transparent">
            <div class="card-body mb-3 bg-transparent">
                <h1 class="card-title"><?= $ferramenta->getNome() ?></h1>
                <div class="card-subtitle"><?= $ferramenta->getGrupo()  ?></div>
                <img class="rounded-4 align-self-center" src="<?= $ferramenta->getImagem() ?>" alt="" style="height: 250px; width: 250px;">


                <ul class="list-group list-group-flush bg-transparent">
                    <div class="card-text list-group-item bg-transparent"><?= $ferramenta->getDescricao() ?></div>
                    <div class="list-group-item bg-transparent">
                        <?php switch ($ferramenta->getMaterial()):
                            case "A": ?>
                                <p>Feito de Aço</p>
                                <?php break; ?>

                            <?php
                            case "C": ?>
                                <p>Feito de Couro</p>
                                <?php break; ?>

                            <?php
                            case "M": ?>
                                <p>Feito de Madeira</p>
                                <?php break; ?>

                            <?php
                            default: ?>
                                <p>Outro material foi utilizado</p>
                        <?php endswitch; ?>
                    </div>

                    <div class="list-group-item bg-transparent">Requisito :<?= $ferramenta->getRequisito() ?></div>

                    <div class="list-group-item bg-transparent">Valor : $<?= $ferramenta->getPreco() ?></div>

                    <?php switch ($ferramenta->getTipo()):
                        case "A": ?>
                            <div class="list-group-item bg-transparent">
                                <p>Dano: <?= $ferramenta->getDano() ?> HP</p>
                            </div>
                            <div class="list-group-item bg-transparent">
                                <p>Bônus de proficiência: <?= $ferramenta->getBonus() ?></p>
                            </div>
                            <div class="list-group-item bg-transparent">
                                <p>Tipo de dano: <?= $ferramenta->getTipoDano() ?></p>
                            </div>
                            <?php break; ?>

                        <?php

                        case "D": ?>
                            <div class="list-group-item bg-transparent">
                                <p>Conjunto: <?= $ferramenta->getConjunto() ?></p>
                            </div>
                            <div class="list-group-item bg-transparent">
                                <p>Defesa: <?= $ferramenta->getDefesa() ?> CA</p>
                            </div>
                            <?php break; ?>

                    <?php endswitch; ?>


                </ul>

                <a href="index.php" class="btn btn-dark"> Voltar</a>
            </div>
        </div>
    </div>
</body>
<script src="scripts/script.js"></script>
<script src="scripts/audio.js"></script>

</html>