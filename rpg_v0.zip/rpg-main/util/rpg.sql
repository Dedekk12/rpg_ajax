CREATE TABLE `ferramenta` (
  `id` int(11) NOT NULL,
  `idHabilidade` int(11) DEFAULT NULL,
  `nome` varchar(20) NOT NULL,
  `tipo` varchar(1) NOT NULL,
  `grupo` varchar(40) NOT NULL,
  `descricao` varchar(70) NOT NULL,
  `preco` double NOT NULL,
  `material` varchar(1) NOT NULL,
  `requisito` varchar(40) NOT NULL,
  `imagem` varchar(200) NOT NULL,
  `dano` int(11) DEFAULT NULL,
  `bonus` int(11) DEFAULT NULL,
  `tipoDano` varchar(20) DEFAULT NULL,
  `defesa` int(11) DEFAULT NULL,
  `conjunto` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `ferramenta`
--

INSERT INTO `ferramenta` (`id`, `idHabilidade`, `nome`, `tipo`, `grupo`, `descricao`, `preco`, `material`, `requisito`, `imagem`, `dano`, `bonus`, `tipoDano`, `defesa`, `conjunto`) VALUES
(23, NULL, 'Wakizashi', 'A', 'Espada', 'Espada utilizada pelos guerreiros orientais', 20000, 'A', 'Dex +3', 'https://upload.wikimedia.org/wikipedia/commons/b/bb/Samurai_with_tachi.png', 150, 4, 'Cortante', NULL, NULL),
(24, NULL, 'Peitoral de Couro', 'D', 'Armadura', 'Oferece pouca proteção', 2100, 'C', '+3 de força', 'https://upload.wikimedia.org/wikipedia/commons/0/0d/G%C3%A9ricault_-_Portrait_de_carabinier_-_Louvre.jpg', NULL, NULL, NULL, 5, 'Couro'),
(25, NULL, 'Mochila de Couro', 'F', 'Bolsa', 'Pode carregar até 10 Kg', 200, 'C', 'N/D', 'https://m.media-amazon.com/images/I/71jv8j01RTL._AC_SY741_.jpg', NULL, NULL, NULL, NULL, NULL),
(26, NULL, 'Elmo de Diamante', 'D', 'Elmo', 'Oferece grande proteção contra ataques mágicos', 231000, 'O', 'Força +3', 'https://minecraft.wiki/images/Diamond_Helmet_JE2_BE2.png?a4954', NULL, NULL, NULL, 20, 'Diamante'),
(27, NULL, 'Arco Longo', 'A', 'Arco', 'Arco simples, mas confiável', 120, 'M', 'Dex +1', 'https://upload.wikimedia.org/wikipedia/commons/1/1b/Englishlongbow.jpg', 25, 3, 'Perfurante', NULL, NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `ferramenta`
--
ALTER TABLE `ferramenta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idHabilidade` (`idHabilidade`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `ferramenta`
--
ALTER TABLE `ferramenta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `ferramenta`
--
ALTER TABLE `ferramenta`
  ADD CONSTRAINT `ferramenta_ibfk_1` FOREIGN KEY (`idHabilidade`) REFERENCES `habilidade` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
