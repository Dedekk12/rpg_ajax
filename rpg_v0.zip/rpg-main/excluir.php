<?php

require_once("util/Conexao.php");

if(isset($_GET['id']) && $_GET['id'] != "")
    $id = $_GET['id'];

if($id > 0){
    $conn = Conexao::getConexao();
    $sql = "DELETE FROM ferramenta WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]    );
    header("location: index.php");
}

else{
    print "<p>ID Inválido!!!</p>";
    print"<a href='index.php'>Voltar à página inicial</a>";
}