<?php

require_once "util/Conexao.php";
require_once "modelo/Arma.php";
require_once "modelo/Armadura.php";
require_once "modelo/Ferramenta.php";
require_once "dao/FerramentasDAO.php";

$conexao = conexao::getConexao();

//salvar os dados
$ferramenta = "";

$classe = "";
$nome = "";
$grupo = "";
$descricao = "";
$preco = "";
$material = "";
$requisito = "";
$imagem = "";
$defesa = "";
$conjunto = "";
$dano = "";
$bonus = "";
$tipoDano = "";

if (isset($_POST["classe"])) {
    $classe = $_POST["classe"]  ? $_POST["classe"] : null;
    $nome = $_POST["nome"] ? $_POST["nome"] : null;
    $grupo = $_POST["grupo"] ? $_POST["grupo"] : null;
    $descricao = $_POST["descricao"] ? $_POST["descricao"] : null;
    $preco = is_numeric($_POST["preco"]) ? $_POST["preco"] : null;
    $material = $_POST["material"] ? $_POST["material"] : null;
    $requisito = $_POST["requisito"] ? $_POST["requisito"] : null;
    $imagem = $_POST["imagem"] ? $_POST["imagem"] :  null;

    //validacao

    $erro = array();

    if (!$classe) {
        $msg = "Informe o tipo do item!";
        array_push($erro, $msg);
    }

    if (!$nome) {
        $msg = "Informe o nome do item!";
        array_push($erro, $msg);
    } elseif (strlen($nome) > 20) {
        $msg = "O nome não pode ter mais de 20 caracteres!";
        array_push($erro, $msg);
    }

    if (!$descricao) {
        $msg = "Informe a descricao do item!";
        array_push($erro, $msg);
    } elseif (strlen($descricao) > 70) {
        $msg = "A descrição não pode ter mais de 40 caracteres!";
        array_push($erro, $msg);
    }

    if (!$preco) {
        $msg = "Informe o preço do item!";
        array_push($erro, $msg);
    } elseif ($preco < 0) {
        $msg = "O preço não pode ser negativo!!!";
        array_push($erro, $msg);
    }

    if (!$material) {
        $msg = "Informe o material do item!";
        array_push($erro, $msg);
    }

    if(!$grupo){
        $msg = "Informe o grupo do item!!!";
        array_push($erro, $msg);
    }

    if (!$requisito) {
        $msg = "Informe o requisito para utilizar o item!";
        array_push($erro, $msg);
    } elseif (strlen($requisito) > 20) {
        $msg = "O requisito não pode ter mais de 20 caracteres!";
        array_push($erro, $msg);
    }

    if (!$imagem) {
        $msg = "Informe um link para uma imagem do item!";
        array_push($erro, $msg);
    }

    switch ($classe) {
        case "F":
            if (empty($erro)) {
                $ferramenta = new Ferramenta($nome, $grupo, $descricao, $preco, $material, $requisito, $imagem);
                FerramentaDao::inserirFerramenta($ferramenta);
                header("location: index.php");
                exit;
            }
            break;

        case "AD":
            $defesa = is_numeric($_POST["defesa"]) ? $_POST["defesa"] : null;
            $conjunto = $_POST["conjunto"] ? $_POST["conjunto"] : null;

            if (!$defesa) {
                $msg = "Informe a defesa para utilizar a armadura!";
                array_push($erro, $msg);
            } elseif ($defesa < 0) {
                $msg = "A defesa não pode ser negativa!!!";
                array_push($erro, $msg);
            }

            if (!$conjunto) {
                $msg = "Informe o conjunto da armadura!";
                array_push($erro, $msg);
            } elseif (strlen($conjunto) > 20) {
                $msg = "O conjunto não pode ter mais de 20 caracteres!";
                array_push($erro, $msg);
            }

            if (empty($erro)) {
                $ferramenta = new Armadura($nome, $grupo, $descricao, $preco, $material, $requisito, $imagem, $defesa, $conjunto);
                FerramentaDao::inserirFerramenta($ferramenta);
                header("location: index.php");
                exit;
            }


            break;

        case "AR":
            $dano = is_numeric($_POST["dano"]) ? $_POST["dano"] : null;
            $bonus = is_numeric($_POST["bonus"]) ? $_POST["bonus"] : null;
            $tipoDano = $_POST["tipoDano"] ? $_POST["tipoDano"] : null;

            if (!$dano) {
                $msg = "Informe o dano da espada!";
                array_push($erro, $msg);
            } elseif ($dano < 0) {
                $msg = "O dano da espada não pode ser negativo!!!";
                array_push($erro, $msg);
            }

            if (!$bonus) {
                $msg = "Informe o bônus de proficiência da espada!";
                array_push($erro, $msg);
            } elseif ($bonus < 0) {
                $msg = "O bônus de proficiência não pode ser negativo!!!";
                array_push($erro, $msg);
            }

            if (!$tipoDano) {
                $msg = "Informe o tipo de dano da espada!";
                array_push($erro, $msg);
            } elseif (strlen($tipoDano) > 20) {
                $msg = "O tipo de dano não pode ter mais de 20 caracteres!";
                array_push($erro, $msg);
            }

            if (empty($erro)) {
                $ferramenta = new Arma($nome, $grupo, $descricao, $preco, $material, $requisito, $imagem, $dano, $bonus, $tipoDano);
                FerramentaDao::inserirFerramenta($ferramenta);
                header("location: index.php");
                exit;
            }


            break;
    }
}






//listar os dados

$ferramentas = FerramentaDao::listarFerramentas();
// print_r($ferramentas);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RPG</title>
    <link rel="stylesheet" href="style/bootstrap.min.css">
    <link rel="stylesheet" href="style/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400..700&display=swap" rel="stylesheet">


    <style>
        .container {
            animation: 3s ease-in change;
        }
    </style>
</head>

<body>

    <audio id="tema" src="audio/the-bard's-song.mp3" loop muted></audio>
    
    <div class="container mt-3 mb-3">
        <h1 class="text-center">RPG</h1>


        <table class="table table-dark table-striped">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Tipo</th>
                <th>Grupo</th>
                <th>Preço</th>
                <th>Material</th>
                <th>Requisito</th>
                <th>Card</th>
                <th>Excluir</th>
            </tr>

            <?php foreach ($ferramentas as $ferramenta): ?>
                <tr>

                    <td><?= $ferramenta->getId() ?></td>

                    <td><?= $ferramenta->getNome() ?></td>

                    <?php if ($ferramenta->getTipo() == "F"): ?>
                        <td>Ferramenta</td>

                    <?php elseif ($ferramenta->getTipo() == "D"): ?>
                        <td>Armadura</td>

                    <?php elseif ($ferramenta->getTipo() == "A"): ?>
                        <td>Arma</td>

                    <?php endif; ?>

                    <td><?= $ferramenta->getGrupo()?></td>

                    <td><?= $ferramenta->getPreco() ?></td>

                    <?php switch ($ferramenta->getMaterial()):
                        case "A": ?>
                            <td>Aço</td>
                            <?php break; ?>

                        <?php
                        case "C": ?>
                            <td>Couro</td>
                            <?php break; ?>

                        <?php
                        case "M": ?>
                            <td>Madeira</td>
                            <?php break; ?>

                        <?php
                        default: ?>
                            <td>Outro</td>
                    <?php endswitch; ?>

                    <td><?= $ferramenta->getRequisito() ?></td>

                    <td><a class="detalhes" href=<?= "card.php?id=" . $ferramenta->getId() ?>>Card</a></td>

                    <td><a class="excluir" href=<?= "excluir.php?id=" . $ferramenta->getId() ?> onclick="if(!confirm('Confirma a exclusão?')) return false" id="excluir">X</a></td>
                </tr>
            <?php endforeach; ?>

        </table>



        <!-- Formulario -->
        <div class="col-6 p-3">

            <h3 class="">Descreva um item</h3>
            <form method="POST">

                <div class="mb-3 col-4 ">
                    <label for="classe" class="form-label">Tipo:</label>
                    <select class="form-select" id="classe" name="classe">
                        <option value="" selected>---Selecione um tipo---</option>
                        <option value="F" <?= $classe == "F" ? "selected" : "" ?>>Ferramenta</option>
                        <option value="AD" <?= $classe == "AD" ? "selected" : "" ?>>Armadura</option>
                        <option value="AR" <?= $classe == "AR" ? "selected" : "" ?>>Arma</option>
                    </select>
                </div>

                <div class="mb-3 col-4">
                    <label for="nome" class="form-label">Nome:</label>
                    <input type="text" class="form-control form-control-sm" id="nome" name="nome" value="<?= $nome ?>">
                </div>

                <div class="mb-3 col-4">
                    <label for="grupo" class="form-label">Grupo:</label>
                    <input type="text" class="form-control form-control-sm" id="grupo" name="grupo" value="<?= $grupo ?>" placeholder="bolsa, espada, armadura...">
                </div>

                <div class="mb-3">
                    <label for="descricao" class="form-label">Descrição:</label>
                    <input type="text" class="form-control form-control-sm" id="descricao" name="descricao" value="<?= $descricao ?>">
                </div>

                <div class="mb-3 col-4">
                    <label for="preco" class="form-label">Preço:</label>
                    <input type="number" step="0.01" class="form-control form-control-sm" id="preco" name="preco" value="<?= $preco ?>">
                </div>

                <div class="mb-3 col-4 ">
                    <label for="material" class="form-label">Material:</label>
                    <select class="form-select" id="material" name="material">
                        <option value="" selected>---Selecione um material---</option>
                        <option value="A" <?= $material == "A" ? "selected" : "" ?>>Aço</option>
                        <option value="C" <?= $material == "C" ? "selected" : "" ?>>Couro</option>
                        <option value="M" <?= $material == "M" ? "selected" : "" ?>>Madeira</option>
                        <option value="O" <?= $material == "O" ? "selected" : "" ?>>Outro</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="requisito" class="form-label">Requisito:</label>
                    <input type="text" class="form-control form-control-sm" id="requisito" name="requisito" value="<?= $requisito ?>">
                </div>

                <div class="mb-3">
                    <label for="imagem" class="form-label">Imagem:</label>
                    <input type="text" class="form-control form-control-sm" id="imagem" name="imagem" value="<?= $imagem ?>">
                </div>


                <!-- Campos Arma e Armadura  -->
                <div class="caixaItens">
                    <div id="caixaArmadura">
                        <div class="mb-3" id="caixaDefesa">
                            <label for="defesa" class="form-label">Defesa:</label>
                            <input type="number" class="form-control form-control-sm" id="defesa" name="defesa" value="<?= $defesa ?>">
                        </div>

                        <div class="mb-3" id="caixaConjunto">
                            <label for="conjunto" class="form-label">Conjunto:</label>
                            <input type="text" class="form-control form-control-sm" id="conjunto" name="conjunto" value="<?= $conjunto ?>">
                        </div>
                    </div>

                    <div id="caixaArma">
                        <div class="mb-3" id="caixaDano">
                            <label for="dano" class="form-label">Dano:</label>
                            <input type="number" class="form-control form-control-sm" id="dano" name="dano" value="<?= $dano ?>">
                        </div>

                        <div class="mb-3" id="caixaBonus">
                            <label for="bonus" class="form-label">Bônus de Proficiência:</label>
                            <input type="number" class="form-control form-control-sm" id="bonus" name="bonus" value="<?= $bonus ?>">
                        </div>

                        <div class="mb-3" id="caixaTipoDano">
                            <label for="tipoDano" class="form-label">Tipo de Dano:</label>
                            <input type="text" class="form-control form-control-sm" id="tipoDano" name="tipoDano" value="<?= $tipoDano ?>">
                        </div>
                    </div>



                </div>


                <button type="submit" class="btn btn-dark">Enviar</button>
            </form>
        </div>
        <?php
        if (!empty($erro)) {

            foreach ($erro as $e) {
                print "<br>$e<br>";
            }
        }

        ?>
    </div>

</body>
<script src="scripts/script.js"></script>
<script src="scripts/audio.js"></script>

</html>
