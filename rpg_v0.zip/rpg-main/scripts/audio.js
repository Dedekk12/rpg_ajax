document.addEventListener("DOMContentLoaded", () => {
    let audio = document.getElementById("tema");
    console.log(audio.muted)

    document.body.addEventListener("click", () => {
        audio.muted = false;
        audio.volume = 0.25;
        audio.play();
    })
    
    
})