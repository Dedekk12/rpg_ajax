/*let classe = document.getElementById("classe");
let caixaDefesa = document.getElementById("caixaDefesa");
let caixaConjunto = document.getElementById("caixaConjunto");
let caixaDano = document.getElementById("caixaDano");
let caixaBonus = document.getElementById("caixaBonus");
let caixaTipoDano = document.getElementById("caixaTipoDano");
*/
let caixaArma = document.getElementById("caixaArma");
let caixaArmadura = document.getElementById("caixaArmadura");
let caixaItens = document.getElementsByClassName("caixaItens");

caixaArma.style.display = "none";
caixaArmadura.style.display = "none"


/*
caixaDefesa.style.display = "none";
caixaConjunto.style.display = "none";
caixaBonus.style.display = "none";
caixaDano.style.display = "none";
caixaTipoDano.style.display = "none";
*/




if (classe.value === "F" || classe.value === "") {
        /*caixaDefesa.style.display = "none";
        caixaConjunto.style.display = "none";
        caixaBonus.style.display = "none";
        caixaDano.style.display = "none";
        caixaTipoDano.style.display = "none";*/

        caixaArma.style.display = "none"
        caixaArmadura.style.display = "none"


    }

    //armadura
    else if (classe.value === "AD") {
        /*caixaDefesa.style.display = "block";
        caixaConjunto.style.display = "block";
        caixaBonus.style.display = "none";
        caixaDano.style.display = "none";
        caixaTipoDano.style.display = "none";*/
        caixaArma.style.display = "none"
        caixaArmadura.style.display= "block";
        caixaArmadura.style.animation = "5s linear change";
        
    }

    //arma
    else if (classe.value === "AR") {
        /*caixaDefesa.style.display = "none";
        caixaConjunto.style.display = "none";
        caixaBonus.style.display = "block";
        caixaDano.style.display = "block";
        caixaTipoDano.style.display = "block";*/

        caixaArma.style.display = "block"
        caixaArmadura.style.display = "none";
        caixaArma.style.animation = "5s linear change";
    }

//ferramenta
classe.addEventListener('change', () => {
    if (classe.value === "F" || classe.value === "") {
        /*caixaDefesa.style.display = "none";
        caixaConjunto.style.display = "none";
        caixaBonus.style.display = "none";
        caixaDano.style.display = "none";
        caixaTipoDano.style.display = "none";*/

        caixaArma.style.display = "none"
        caixaArmadura.style.display = "none"


    }

    //armadura
    else if (classe.value === "AD") {
        /*caixaDefesa.style.display = "block";
        caixaConjunto.style.display = "block";
        caixaBonus.style.display = "none";
        caixaDano.style.display = "none";
        caixaTipoDano.style.display = "none";*/
        caixaArma.style.display = "none"
        caixaArmadura.style.display= "block";
        caixaArmadura.style.animation = "5s linear change";
        
    }

    //arma
    else if (classe.value === "AR") {
        /*caixaDefesa.style.display = "none";
        caixaConjunto.style.display = "none";
        caixaBonus.style.display = "block";
        caixaDano.style.display = "block";
        caixaTipoDano.style.display = "block";*/

        caixaArma.style.display = "block"
        caixaArmadura.style.display = "none";
        caixaArma.style.animation = "5s linear change";
    }
})
