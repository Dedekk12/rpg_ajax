<?php
//Requisitos

require_once("modelo/Arma.php");
require_once("modelo/Armadura.php");
require_once("modelo/Ferramenta.php");

class FerramentaDAO
{

    public static function inserirFerramenta(Ferramenta $ferramenta)
    {
        $sql = "INSERT INTO 
                Ferramenta(nome,tipo,descricao,preco, material,requisito,imagem,dano,bonus,tipoDano,defesa,conjunto,grupo) 
                VALUES
                (?,?,?,?,?,?,?,?,?,?,?,?,?)";

        $conn = Conexao::getConexao();
        $stm = $conn->prepare($sql);

        if ($ferramenta instanceof Arma) {
            $stm->execute(array(
                $ferramenta->getNome(),
                $ferramenta->getTipo(),
                $ferramenta->getDescricao(),
                $ferramenta->getPreco(),
                $ferramenta->getMaterial(),
                $ferramenta->getRequisito(),
                $ferramenta->getImagem(),
                $ferramenta->getDano(),
                $ferramenta->getBonus(),
                $ferramenta->getTipoDano(),
                null,
                null,
                $ferramenta->getGrupo()
            ));
        } elseif ($ferramenta instanceof Armadura) {
            $stm->execute(array(
                $ferramenta->getNome(),
                $ferramenta->getTipo(),
                $ferramenta->getDescricao(),
                $ferramenta->getPreco(),
                $ferramenta->getMaterial(),
                $ferramenta->getRequisito(),
                $ferramenta->getImagem(),
                null,
                null,
                null,
                $ferramenta->getDefesa(),
                $ferramenta->getConjunto(),
                $ferramenta->getGrupo()
            ));
        } elseif ($ferramenta instanceof Ferramenta) {
            $stm->execute(array(
                $ferramenta->getNome(),
                $ferramenta->getTipo(),
                $ferramenta->getDescricao(),
                $ferramenta->getPreco(),
                $ferramenta->getMaterial(),
                $ferramenta->getRequisito(),
                $ferramenta->getImagem(),
                null,
                null,
                null,
                null,
                null,
                $ferramenta->getGrupo()
            ));
        }
    }

    public static function listarFerramentas()
    {
        $sql = "SELECT * FROM Ferramenta";

        $conn = Conexao::getConexao();
        $stm = $conn->prepare($sql);
        $stm->execute();

        $dados = $stm->fetchAll();

        $ferramentas = self::map($dados);

        //print_r($dados);

        return $ferramentas;
    }

    public static function buscarFerramenta(int $id)
    {
        $sql = "SELECT* FROM Ferramenta WHERE id = ?";

        $conn = Conexao::getConexao();
        $stm = $conn->prepare($sql);
        $stm->execute(array($id));

        $dados = $stm->fetchAll();

        //print_r($dados);

        $ferramenta = self::map($dados);

        return $ferramenta;
    }

    public static function deletarFerramenta(int $idFerramenta)
    {
        $sql = "DELETE FROM Ferramenta WHERE id = ?";

        $conn = Conexao::getConexao();
        $stm = $conn->prepare($sql);

        $stm->execute(array($idFerramenta));
    }


    //ORM (tabela -> objeto)
    private static function map(array $dados)
    {
        $ferramentas = [];
        foreach ($dados as $d) {
            $ferramenta = null;
            if ($d['tipo'] == "A") {
                $ferramenta = new Arma($d['nome'],$d['grupo'],  $d['descricao'], $d['preco'], $d['material'], $d['requisito'], $d['imagem'], $d['dano'], $d['bonus'], $d['tipoDano']);
            } elseif ($d['tipo'] == "D") {
                $ferramenta = new Armadura($d['nome'],$d['grupo'],   $d['descricao'], $d['preco'], $d['material'], $d['requisito'], $d['imagem'], $d['defesa'], $d['conjunto']);
            } elseif ($d['tipo'] == "F") {
                $ferramenta = new Ferramenta($d['nome'],$d['grupo'], $d['descricao'], $d['preco'], $d['material'], $d['requisito'], $d['imagem']);
            }

            $ferramenta->setId($d['id']);
            array_push($ferramentas, $ferramenta);
        }

        return $ferramentas;
    }
}
